﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using NVelocity.App;
using NVelocity.Runtime;
using NVelocity;

namespace ASPNetHttpHandler2
{
    /// <summary>
    /// DisplayNews 的摘要说明
    /// </summary>
    public class DisplayNews : IHttpHandler
    {

        public void ProcessRequest(HttpContext context)
        {
            context.Response.ContentType = "text/html";
            VelocityEngine vltEngine = new VelocityEngine();
            vltEngine.SetProperty(RuntimeConstants.RESOURCE_LOADER, "file");
            vltEngine.SetProperty(RuntimeConstants.FILE_RESOURCE_LOADER_PATH, System.Web.Hosting.HostingEnvironment.MapPath("~/templates"));//模板文件所在的文件夹
            vltEngine.Init();

            //把类的定义和对象的声明初始化放到一起
            //匿名类
            var news = new { Title = "特大喜讯",Author="杨中科",PostDate="2013-11-08",Msg="今天晚上会公布喜讯细节！" };
            string s = news.PostDate;           

            VelocityContext vltContext = new VelocityContext();
            vltContext.Put("data", news);

            Template vltTemplate = vltEngine.GetTemplate("displayNews1.htm");
            System.IO.StringWriter vltWriter = new System.IO.StringWriter();
            vltTemplate.Merge(vltContext, vltWriter);

            string html = vltWriter.GetStringBuilder().ToString();
            context.Response.Write(html);
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}