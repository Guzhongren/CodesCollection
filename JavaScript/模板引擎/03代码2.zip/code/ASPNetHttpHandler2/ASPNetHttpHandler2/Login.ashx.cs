﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ASPNetHttpHandler2
{
    /// <summary>
    /// Login 的摘要说明
    /// </summary>
    public class Login : IHttpHandler
    {

        public void ProcessRequest(HttpContext context)
        {
            context.Response.ContentType = "text/html";
            string username=context.Request["username"];
            string password = context.Request["password"];

            string html = "<html><head></head><body><strong><font color='red'>登录</font></strong><form action='Login.ashx'><input type='text' name='username' value='{username}'/><input type='password' name='password' value='{password}' /><input type='submit' value='登录'/></form><p>{msg}</p></body></html>";

            if (string.IsNullOrEmpty(username) && string.IsNullOrEmpty(password))
            {
                //context.Response.Write("<html>");
                //context.Response.Write("<head></head>");
                //context.Response.Write("<body><strong><font color='red'>登录</font></strong><form action='Login.ashx'><input type='text' name='username'/><input type='password' name='password'/><input type='submit' value='登录'/></form></body>");
                //context.Response.Write("</html>");

                string code = html.Replace("{username}", "");
                code = code.Replace("{password}", "");
                code = code.Replace("{msg}", "");
                context.Response.Write(code);
            }
            else
            {
                if (username == "admin" && password == "123")
                {
                    context.Response.Write("<html><head></head><body>登录成功</body></html>");
                }
                else
                {
                    //context.Response.Write("<html>");
                    //context.Response.Write("<head></head>");
                    //context.Response.Write("<body><strong><font color='red'>登录</font></strong><form action='Login.ashx'><input type='text' name='username' value='" + username + "' /><input type='password' name='password' value='" + password + "'/><input type='submit' value='登录'/><p>用户名或者密码错误</p></form></body>");
                    //context.Response.Write("</html>");
                    ////context.Response.Write("<html><head></head><body>用户名或者密码错误</body></html>");

                    string code = html.Replace("{username}",username);
                    code = code.Replace("{password}", password);
                    code = code.Replace("{msg}", "用户名或者密码错误");
                    context.Response.Write(code);
                }
            }
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}