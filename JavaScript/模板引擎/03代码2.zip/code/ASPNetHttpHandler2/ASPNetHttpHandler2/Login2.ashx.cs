﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using NVelocity.App;
using NVelocity.Runtime;
using NVelocity;

namespace ASPNetHttpHandler2
{
    /// <summary>
    /// Login2 的摘要说明
    /// </summary>
    public class Login2 : IHttpHandler
    {

        public void ProcessRequest(HttpContext context)
        {
            context.Response.ContentType = "text/html";

            Person person = new Person();
            person.Name = "yzk";
            person.Age = 30;
            Person dad = new Person();

            dad.Name = "ywx";
            dad.Age = 60;

            person.Father = dad;

            VelocityEngine vltEngine = new VelocityEngine();
            vltEngine.SetProperty(RuntimeConstants.RESOURCE_LOADER, "file");
            vltEngine.SetProperty(RuntimeConstants.FILE_RESOURCE_LOADER_PATH, System.Web.Hosting.HostingEnvironment.MapPath("~/templates"));//模板文件所在的文件夹
            vltEngine.Init();

            VelocityContext vltContext = new VelocityContext();
            vltContext.Put("p", person);//设置参数，在模板中可以通过$data来引用
            Template vltTemplate = vltEngine.GetTemplate("test.htm");
            System.IO.StringWriter vltWriter = new System.IO.StringWriter();
            vltTemplate.Merge(vltContext, vltWriter);

            string html = vltWriter.GetStringBuilder().ToString();
            context.Response.Write(html);

            //string username = context.Request["username"];
            //string password = context.Request["password"];
            //if (string.IsNullOrEmpty(username) && string.IsNullOrEmpty(password))
            //{
            //    VelocityEngine vltEngine = new VelocityEngine();
            //    vltEngine.SetProperty(RuntimeConstants.RESOURCE_LOADER, "file");
            //    vltEngine.SetProperty(RuntimeConstants.FILE_RESOURCE_LOADER_PATH, System.Web.Hosting.HostingEnvironment.MapPath("~/templates"));//模板文件所在的文件夹
            //    vltEngine.Init();

            //    VelocityContext vltContext = new VelocityContext();
            //    vltContext.Put("username", "");//设置参数，在模板中可以通过$data来引用
            //    vltContext.Put("password", "");
            //    vltContext.Put("msg", "");
            //    Template vltTemplate = vltEngine.GetTemplate("login.htm");
            //    System.IO.StringWriter vltWriter = new System.IO.StringWriter();
            //    vltTemplate.Merge(vltContext, vltWriter);

            //    string html = vltWriter.GetStringBuilder().ToString();
            //    context.Response.Write(html);
            //}
            //else
            //{
            //    if (username == "admin" && password == "123")
            //    {
            //        context.Response.Write("登录成功");
            //    }
            //    else
            //    {
            //        VelocityEngine vltEngine = new VelocityEngine();
            //        vltEngine.SetProperty(RuntimeConstants.RESOURCE_LOADER, "file");
            //        vltEngine.SetProperty(RuntimeConstants.FILE_RESOURCE_LOADER_PATH, System.Web.Hosting.HostingEnvironment.MapPath("~/templates"));//模板文件所在的文件夹
            //        vltEngine.Init();

            //        VelocityContext vltContext = new VelocityContext();
            //        vltContext.Put("username", username);//设置参数，在模板中可以通过$data来引用
            //        vltContext.Put("password", password);
            //        vltContext.Put("msg", "用户名或者密码错误");

            //        Template vltTemplate = vltEngine.GetTemplate("login.htm");
            //        System.IO.StringWriter vltWriter = new System.IO.StringWriter();
            //        vltTemplate.Merge(vltContext, vltWriter);

            //        string html = vltWriter.GetStringBuilder().ToString();
            //        context.Response.Write(html);
            //    }
            //}
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}